<?php

namespace MediaWiki\Settings\Source;

use RuntimeException;

class RefLoopException extends RuntimeException {

}
